var typed = new Typed('#typed', {
    strings: ['I am a <b>Web Designer</b>', 'I am a <b>Web Developer</b>','I am a <b>Software Developer</b>'],
    loop: true,
    smartBackspace: true, // Default value
    typeSpeed: 40,
});